// 与另一个script标签通信。 showTeacher为true表示displayInfo页面显示教师信息
let showTeacher = new Boolean;